package assignment07;

public interface Menu{
    public MenuEntryIterator createIterator();
}
