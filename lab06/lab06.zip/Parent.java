package lab06;

public class Parent {
	public boolean isChild(){
		return false;
	}
	public String toString(){
		return "I am a Parent";
	}
}
