package lab06;

public class Child extends Parent {
	public boolean isChild(){
		return true;
	}
	public String toString(){
		return "I am a Child";
	}
}
