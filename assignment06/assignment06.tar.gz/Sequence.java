package assignment06;
public interface Sequence
{
   int next();
}
