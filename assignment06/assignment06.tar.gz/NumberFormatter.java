package assignment06;

public interface NumberFormatter{
    String format(int n);
}
